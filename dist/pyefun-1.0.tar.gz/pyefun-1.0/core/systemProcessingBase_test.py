import unittest

from .systemProcessingBase import *
from ubelt import *
from . import *


class TestSystemProcessingBase(unittest.TestCase):

    def test_1(self):
        pass
        data = 运行("ipconfig")
        print(data)

    def test_2(self):
        pass
        data = 取鼠标位置()
        print(data.x)
        print(data.y)
